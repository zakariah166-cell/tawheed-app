#!/usr/bin/env bash
# بناء APK محليًا (يتطلب: Node 20+، JDK 21، Android SDK مع ANDROID_HOME)
set -e
npm install
[ -d android ] || npx cap add android
npx capacitor-assets generate --android
M=android/app/src/main/AndroidManifest.xml
grep -q supportsRtl "$M" || sed -i 's|<application|<application android:supportsRtl="true"|' "$M"
npx cap sync android
(cd android && ./gradlew assembleDebug)
echo "الملف الجاهز: android/app/build/outputs/apk/debug/app-debug.apk"
